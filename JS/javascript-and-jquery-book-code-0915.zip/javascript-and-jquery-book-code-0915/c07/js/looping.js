$('li em').addClass('seasonal');
$('li.hot').addClass('favorite');